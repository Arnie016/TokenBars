# TokenBar

TokenBar is a local-first CLI token usage and budget bar for coding agents and developer workflows.

It gives you a quick terminal view of token usage, budget status, reset timing, power estimate, and natural-language prompts like:

```bash
will I run out?
why spike?
show folders
set daily limit 100M
heat?
